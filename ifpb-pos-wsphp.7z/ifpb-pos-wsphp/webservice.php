<?php

//importação da bilioteca NuSOAP - SOAP Toolkit for PHP
include ("./lib/nusoap.php");

//instância um servidor webservice usando o protocolo soap
$webService = new soap_server();

//assina a função 'check' para que ela possa ser consumida pelos clientes do webservice
$webService->register("check");

//função que verifica se um numero passado por parametro é par ou impar
function check($x) {
    return !($x % 2) ? "Par" : "Impar";
}

//formato de dados trocados pelo servidor webservice
$webService->service($HTTP_RAW_POST_DATA);
?>

